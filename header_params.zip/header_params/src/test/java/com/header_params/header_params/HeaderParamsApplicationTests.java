package com.header_params.header_params;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HeaderParamsApplicationTests {

	@Test
	void contextLoads() {
	}

}
