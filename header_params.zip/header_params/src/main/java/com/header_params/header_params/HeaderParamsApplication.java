package com.header_params.header_params;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HeaderParamsApplication {
	public static void main(String[] args) {
		SpringApplication.run(HeaderParamsApplication.class, args);
	}
}


