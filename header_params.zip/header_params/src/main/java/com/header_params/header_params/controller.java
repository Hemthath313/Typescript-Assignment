package com.header_params.header_params;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class controller {
    @GetMapping("/example")
    public ResponseEntity<String> exampleEndpoint(
            @RequestHeader("Custom-Header") String customHeader,
            @RequestParam("param1") String requestParam) {
        // Process the request parameter and custom header
        String result = "Request Parameter: " + requestParam;

        // Add a custom response header
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.add("Custom-Response-Header", "ResponseHeaderValue");

        return ResponseEntity.ok()
                .headers(responseHeaders)
                .body(result);
    }
}
